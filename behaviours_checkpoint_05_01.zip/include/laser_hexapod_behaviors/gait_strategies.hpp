#ifndef LASER_HEXAPOD_BEHAVIORS__GAIT_STRATEGIES_HPP
#define LASER_HEXAPOD_BEHAVIORS__GAIT_STRATEGIES_HPP

#include <vector>
#include <utility>
#include <memory>

namespace laser_hexapod_behaviors
{

//
using StepSequence = std::vector<std::pair<int, std::vector<double>>>;

class GaitSequence {
public:
    virtual ~GaitSequence() = default;
    virtual StepSequence getSteps() = 0;
};

class CeilingGait : public GaitSequence {
public:
    StepSequence getSteps() override;
};

class WallDownGait : public GaitSequence {
public:
    StepSequence getSteps() override;
};

class WallUpGait : public GaitSequence {
public:
    StepSequence getSteps() override;
};

class WallSideGait : public GaitSequence {
public:
    StepSequence getSteps() override;
};

class GroundGait : public GaitSequence {
public:
    StepSequence getSteps() override;
};

class GaitFactory {
public:
    static std::unique_ptr<GaitSequence> createGait(double roll, double pitch);
};

} // namespace laser_hexapod_behaviors

#endif