#include <laser_hexapod_behaviors/constants.hpp>
#include <laser_hexapod_behaviors/robot_state.hpp>
#include <laser_hexapod_behaviors/cross_obstacle_new.hpp>

namespace laser_hexapod_behaviors
{
    std::unique_ptr<RobotState> ExecutingState::update(CrossObstacle &ctx, const RobotInputs &inputs)
    {
        // auto logger = rclcpp::get_logger("contact_debug");
        // static rclcpp::Clock clock;
        // static auto last_print_time = clock.now();

        // 2. Manual Throttle Check (Runs once every 1.0 seconds)
        // if ((clock.now() - last_print_time).seconds() > 1.0)
        // {
        //     std::stringstream ss;
        //     ss << "Contacts: ";
        //     for (auto k = 0; k <= LL3; k++)
        //     {
        //         // Format: [LegID: T/F]
        //         ss << "[" << k << ":" << (inputs.contact_sensors.data[k] ? "ON" : "OFF") << "] ";
        //     }
        //     // Print ONE summary line for all legs
        //     RCLCPP_INFO(logger, "%s", ss.str().c_str());

        //     last_print_time = clock.now();
        // }

        // // 3. Your Logic Loop (Runs every tick, uninterrupted)
        // for (auto i = 0; i <= LL3; i++)
        // {
        //     // ... (rest of your logic) ...
        //     if (ctx.current_legs_reference_.foot_state[i].data == "stance" &&
        //         !inputs.contact_sensors.data[i] &&
        //         ctx.references_per_step_[ctx.current_step_].first != i &&
        //         inputs.foot_errors[i].data < 0.01)
        //     {
        //         // Warn immediately if slip happens
        //         RCLCPP_WARN(logger, "SLIP DETECTED on Leg %d! Switching to Recovery.", i);
        //         return std::make_unique<SlipRecoveryState>();
        //     }
        // }

        // 3. Normal Execution Logic
        // Reset flags
        for (auto i = 0; i <= LL3; i++)
        {
            ctx.current_legs_reference_.requested_leg_to_move[i].data = false;
            ctx.current_legs_reference_.foot_state[i].data = "stance";
        }

        // Alias for readability (optional but recommended)
        // auto& current_instruction = ctx.references_per_step_[ctx.current_step_];

        if (ctx.references_per_step_[ctx.current_step_].second[4] == NEED_COUPLE)
        {
            // CASE: COUPLING
            int leg_idx = ctx.references_per_step_[ctx.current_step_].first;

            if (!inputs.contact_sensors.data[leg_idx] && inputs.foot_errors[leg_idx].data < 0.01)
            {
                if (ctx.references_per_step_[ctx.current_step_].second[3] == REFERENCE_IN_WORLD)
                {
                    if (ctx.references_per_step_[ctx.current_step_].second[0] != NONE)
                    {
                        ctx.legs_world_reference_.points[leg_idx].x += 0.005 * ctx.references_per_step_[ctx.current_step_].second[0];
                    }
                    if (ctx.references_per_step_[ctx.current_step_].second[1] != NONE)
                    {
                        ctx.legs_world_reference_.points[leg_idx].y += 0.005 * ctx.references_per_step_[ctx.current_step_].second[1];
                    }
                    if (ctx.references_per_step_[ctx.current_step_].second[2] != NONE)
                    {
                        ctx.legs_world_reference_.points[leg_idx].z += 0.005 * ctx.references_per_step_[ctx.current_step_].second[2];
                    }
                    ctx.transformReferenceWorldToCoxa(leg_idx);
                }
                else
                {
                    ctx.current_legs_reference_.reference.points[leg_idx].z += -0.005;
                }

                ctx.current_legs_reference_.requested_leg_to_move[leg_idx].data = true;
                ctx.current_legs_reference_.foot_state[leg_idx].data = "stance";
            }
            else if (inputs.contact_sensors.data[leg_idx])
            {
                ctx.current_step_++;
            }
        }
        else if (ctx.references_per_step_[ctx.current_step_].first <= LL3)
        {
            // CASE: MOVING LEG (SWING)
            int leg_idx = ctx.references_per_step_[ctx.current_step_].first;

            if (ctx.references_per_step_[ctx.current_step_].second[0] != NONE)
            {
                if (ctx.references_per_step_[ctx.current_step_].second[3] == REFERENCE_IN_WORLD)
                {
                    ctx.legs_world_reference_.points[leg_idx].x = ctx.references_per_step_[ctx.current_step_].second[0];
                }
                else
                {
                    ctx.current_legs_reference_.reference.points[leg_idx].x = ctx.references_per_step_[ctx.current_step_].second[0];
                }
            }

            if (ctx.references_per_step_[ctx.current_step_].second[1] != NONE)
            {
                if (ctx.references_per_step_[ctx.current_step_].second[3] == REFERENCE_IN_WORLD)
                {
                    ctx.legs_world_reference_.points[leg_idx].y = ctx.references_per_step_[ctx.current_step_].second[1];
                }
                else
                {
                    ctx.current_legs_reference_.reference.points[leg_idx].y = ctx.references_per_step_[ctx.current_step_].second[1];
                }
            }

            if (ctx.references_per_step_[ctx.current_step_].second[2] != NONE)
            {
                if (ctx.references_per_step_[ctx.current_step_].second[3] == REFERENCE_IN_WORLD)
                {
                    ctx.legs_world_reference_.points[leg_idx].z = ctx.references_per_step_[ctx.current_step_].second[2];
                }
                else
                {
                    ctx.current_legs_reference_.reference.points[leg_idx].z = ctx.references_per_step_[ctx.current_step_].second[2];
                }
            }

            if (ctx.references_per_step_[ctx.current_step_].second[3] == REFERENCE_IN_WORLD)
            {
                ctx.transformReferenceWorldToCoxa(leg_idx);
            }

            ctx.current_legs_reference_.requested_leg_to_move[leg_idx].data = true;
            ctx.current_legs_reference_.foot_state[leg_idx].data = "swing";

            ctx.current_step_++;
        }
        else if (ctx.references_per_step_[ctx.current_step_].first == BODY)
        {
            // CASE: MOVING BODY
            if (ctx.references_per_step_[ctx.current_step_].second[0] != NONE)
            {
                ctx.body_position_.x = ctx.references_per_step_[ctx.current_step_].second[0];
            }
            if (ctx.references_per_step_[ctx.current_step_].second[1] != NONE)
            {
                ctx.body_position_.y = ctx.references_per_step_[ctx.current_step_].second[1];
            }
            if (ctx.references_per_step_[ctx.current_step_].second[2] != NONE)
            {
                ctx.body_position_.z = ctx.references_per_step_[ctx.current_step_].second[2];
            }
            if (ctx.references_per_step_[ctx.current_step_].second[3] != NONE)
            {
                ctx.body_orientation_.roll = ctx.references_per_step_[ctx.current_step_].second[3];
            }
            if (ctx.references_per_step_[ctx.current_step_].second[4] != NONE)
            {
                ctx.body_orientation_.pitch = ctx.references_per_step_[ctx.current_step_].second[4];
            }
            if (ctx.references_per_step_[ctx.current_step_].second[5] != NONE)
            {
                ctx.body_orientation_.yaw = ctx.references_per_step_[ctx.current_step_].second[5];
            }

            for (auto i = 0; i <= LL3; i++)
            {
                ctx.transformReferenceWorldToCoxa(i);
                ctx.current_legs_reference_.requested_leg_to_move[i].data = true;
                ctx.current_legs_reference_.foot_state[i].data = "stance";
            }

            ctx.current_step_++;
        }

        return nullptr; // No state change needed
    }
}