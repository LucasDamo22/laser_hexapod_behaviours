#include <laser_hexapod_behaviors/cross_obstacle_new.hpp>
#include <laser_hexapod_behaviors/gait_strategies.hpp>
#include <laser_hexapod_behaviors/constants.hpp>
#include <laser_hexapod_behaviors/robot_state.hpp>

// using namespace angles;

namespace laser_hexapod_behaviors
{
  /* CrossObstacle() {default} //{ */
  CrossObstacle::CrossObstacle()
  {
  }
  //}

  /* CrossObstacle() //{ */
  CrossObstacle::CrossObstacle(std::vector<double> distance_body_to_coxa, float admitted_error)
  {
    cross_obstacle_update_counter = 0;
    current_state_ = std::make_unique<StartState>();
    admitted_error_ = admitted_error;
    distance_body_to_coxa_ = std::vector<geometry_msgs::msg::Point>(6, geometry_msgs::msg::Point());
    legs_world_reference_.points = std::vector<geometry_msgs::msg::Point>(6, geometry_msgs::msg::Point());
    current_legs_reference_.reference.points = std::vector<geometry_msgs::msg::Point>(6, geometry_msgs::msg::Point());
    current_legs_reference_.requested_leg_to_move = std::vector<std_msgs::msg::Bool>(6, std_msgs::msg::Bool());
    current_legs_reference_.foot_state = std::vector<std_msgs::msg::String>(6, std_msgs::msg::String());

    for (auto i = 0; i < 6; i++)
    {
      distance_body_to_coxa_[i].x = distance_body_to_coxa[0 + (i * 3)];
      distance_body_to_coxa_[i].y = distance_body_to_coxa[1 + (i * 3)];
      distance_body_to_coxa_[i].z = distance_body_to_coxa[2 + (i * 3)];
    }

    resetBehavior();
  } //}

  /* referencePerStep() //{ */
  void CrossObstacle::referencePerStep(sensor_msgs::msg::Imu imu_data)
  {
    tf2::Quaternion q(imu_data.orientation.x, imu_data.orientation.y, imu_data.orientation.z, imu_data.orientation.w);
    double roll, pitch, yaw;
    tf2::Matrix3x3(q).getRPY(roll, pitch, yaw);

    std::unique_ptr<GaitSequence> gaitStrategy = GaitFactory::createGait(roll, pitch);

    error_aux = admitted_error_;
    references_per_step_ = gaitStrategy->getSteps();
  }

  /* updateStep() //{ */
  laser_msgs::msg::LegsReferenceRequest CrossObstacle::updateStep(laser_msgs::msg::BoolArray contact_sensor,
                                                                  std::vector<std_msgs::msg::Float64> foots_position_error, float highest_foot_position_error)
  {

    auto logger = rclcpp::get_logger("cross_obstacle");
    cross_obstacle_update_counter++;


    RobotInputs inputs{contact_sensor, foots_position_error, highest_foot_position_error};

    while (true)
    {
      std::unique_ptr<RobotState> next_state = current_state_->update(*this, inputs);
      if(!next_state){
        //resetting state machine to start, for next iteration, either because its done, or0 early error
        current_state_ = std::make_unique<StartState>();
        break;
      } else {
        // changing to next_state
        current_state_ = std::move(next_state);
      }
    }
    return current_legs_reference_;
  }

  /* resetBehavior() //{ */
  void CrossObstacle::resetBehavior()
  {
    current_step_ = 0;

    for (auto i = 0; i < 6; i++)
    {
      legs_world_reference_.points[i].x = 0;
      if (i <= LR3)
      {
        legs_world_reference_.points[i].y = -0.29;
      }
      else
      {
        legs_world_reference_.points[i].y = 0.29;
      }
      legs_world_reference_.points[i].z = 0.0;

      current_legs_reference_.reference.points[i].x = 0;
      current_legs_reference_.reference.points[i].y = 0.29;
      current_legs_reference_.reference.points[i].z = -0.21;

      current_legs_reference_.foot_state[i].data = "stance";
    }

    body_position_.x = 0;
    body_position_.y = 0;
    body_position_.z = 0;

    body_orientation_.roll = 0;
    body_orientation_.pitch = 0;
    body_orientation_.yaw = 0;
  }
  //}

  /* getCurrentStep() //{ */
  int CrossObstacle::getCurrentStep()
  {
    return current_step_;
  }
  //}

  /* getTotalSteps() //{ */
  int CrossObstacle::getTotalSteps()
  {
    return references_per_step_.size();
  }
  //}

  /* transformReferenceWorldToCoxa() //{ */
  void CrossObstacle::transformReferenceWorldToCoxa(int index_leg)
  {
    Eigen::Matrix4d translation_wb = Eigen::Matrix4d::Identity();
    translation_wb(0, 3) = body_position_.x;
    translation_wb(1, 3) = body_position_.y;
    translation_wb(2, 3) = body_position_.z;

    Eigen::Matrix4d transform_wb = Eigen::Matrix4d::Identity();
    transform_wb(0, 3) = legs_world_reference_.points[index_leg].x + distance_body_to_coxa_[index_leg].x;
    transform_wb(1, 3) = legs_world_reference_.points[index_leg].y + distance_body_to_coxa_[index_leg].y;
    transform_wb(2, 3) = legs_world_reference_.points[index_leg].z + distance_body_to_coxa_[index_leg].z;

    Eigen::Matrix4d rot_x_wb = Eigen::Matrix4d::Identity();
    rot_x_wb(1, 1) = cos(body_orientation_.roll);
    rot_x_wb(1, 2) = -sin(body_orientation_.roll);
    rot_x_wb(2, 1) = sin(body_orientation_.roll);
    rot_x_wb(2, 2) = cos(body_orientation_.roll);

    Eigen::Matrix4d rot_y_wb = Eigen::Matrix4d::Identity();
    rot_y_wb(0, 0) = cos(body_orientation_.pitch);
    rot_y_wb(0, 2) = sin(body_orientation_.pitch);
    rot_y_wb(2, 0) = -sin(body_orientation_.pitch);
    rot_y_wb(2, 2) = cos(body_orientation_.pitch);

    Eigen::Matrix4d rot_z_wb = Eigen::Matrix4d::Identity();
    rot_z_wb(0, 0) = cos(body_orientation_.yaw);
    rot_z_wb(0, 1) = -sin(body_orientation_.yaw);
    rot_z_wb(1, 0) = sin(body_orientation_.yaw);
    rot_z_wb(1, 1) = cos(body_orientation_.yaw);

    Eigen::Matrix4d result = translation_wb * rot_x_wb * rot_y_wb * rot_z_wb * transform_wb;

    Eigen::Matrix4d translation_bc = Eigen::Matrix4d::Identity();
    translation_bc(0, 3) = -distance_body_to_coxa_[index_leg].x;
    translation_bc(1, 3) = -distance_body_to_coxa_[index_leg].y;
    translation_bc(2, 3) = -distance_body_to_coxa_[index_leg].z;

    Eigen::Matrix4d rot_z_bc = Eigen::Matrix4d::Identity();

    float leg_rotation = 0.0;
    switch (index_leg)
    {
    case LR1:
      leg_rotation = DEG_225;
      break;
    case LR2:
      leg_rotation = DEG_180;
      break;
    case LR3:
      leg_rotation = DEG_135;
      break;
    case LL1:
      leg_rotation = DEG_315;
      break;
    case LL2:
      leg_rotation = DEG_0;
      break;
    case LL3:
      leg_rotation = DEG_45;
      break;
    }

    rot_z_bc(0, 0) = cos(leg_rotation);
    rot_z_bc(0, 1) = -sin(leg_rotation);
    rot_z_bc(1, 0) = sin(leg_rotation);
    rot_z_bc(1, 1) = cos(leg_rotation);

    result = rot_z_bc * translation_bc * result;

    current_legs_reference_.reference.points[index_leg].x = result(0, 3);
    current_legs_reference_.reference.points[index_leg].y = result(1, 3);
    current_legs_reference_.reference.points[index_leg].z = result(2, 3);
  }
  //}
} // namespace laser_hexapod_behaviors
