#include <laser_hexapod_behaviors/constants.hpp>
#include <laser_hexapod_behaviors/robot_state.hpp>
#include <laser_hexapod_behaviors/cross_obstacle_new.hpp>
namespace laser_hexapod_behaviors
{

    std::unique_ptr<RobotState> AdaptativeErrorState::update(CrossObstacle &ctx, const RobotInputs &inputs)
    {

        // 1. Check if we are still unstable
        if (inputs.max_error > ctx.admitted_error_)
        {

            ctx.adaptative_error_aux++;
            if (ctx.adaptative_error_aux == 5)
            {

                float old_admitted = ctx.admitted_error_;
                ctx.admitted_error_ += 0.005;
                ctx.adaptative_error_aux = 0;
            }
            // error detected, returns null to abort execution
            return nullptr;
        }

        // 2. If stable, reset counters and transition to slippage check state
        ctx.admitted_error_ = ctx.error_aux;
        return std::make_unique<SlipRecoveryState>();
    }
}