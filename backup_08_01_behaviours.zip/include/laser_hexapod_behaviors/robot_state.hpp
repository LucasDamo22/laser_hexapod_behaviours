#ifndef LASER_HEXAPOD_BEHAVIORS__ROBOT_STATE_HPP
#define LASER_HEXAPOD_BEHAVIORS__ROBOT_STATE_HPP

#include <memory>
#include <vector>

#include <geometry_msgs/msg/point.hpp>
#include <std_msgs/msg/float64.hpp>

#include <laser_msgs/msg/legs_reference_request.hpp>
#include <laser_msgs/msg/point_array.hpp>
#include <laser_msgs/msg/bool_array.hpp>
#include <laser_msgs/msg/rpy.hpp>
#include <sensor_msgs/msg/imu.hpp>

namespace laser_hexapod_behaviors {

class CrossObstacle;

struct RobotInputs {
    const laser_msgs::msg::BoolArray& contact_sensors;
    const std::vector<std_msgs::msg::Float64>& foot_errors;
    float max_error;
};

class RobotState {
public:
    virtual ~RobotState() = default;
    
    // Returns the NEXT state. 
    // If nullptr is returned, the execution ends.
    virtual std::unique_ptr<RobotState> update(CrossObstacle& ctx, const RobotInputs& inputs) = 0;
    virtual std::string getName() const = 0;
};

class StartState : public RobotState {
public:
    std::unique_ptr<RobotState> update(CrossObstacle& ctx, const RobotInputs& inputs) override;
    std::string getName() const override { return "START"; }
};

class AdaptativeErrorState : public RobotState {
public:
    std::unique_ptr<RobotState> update(CrossObstacle& ctx, const RobotInputs& inputs) override;
    std::string getName() const override { return "STABILIZING"; }
};

class SlipRecoveryState : public RobotState {
public:
    std::unique_ptr<RobotState> update(CrossObstacle& ctx, const RobotInputs& inputs) override;
    std::string getName() const override { return "RECOVERY"; }
};

class ExecutingState : public RobotState {
public:
    std::unique_ptr<RobotState> update(CrossObstacle& ctx, const RobotInputs& inputs) override;
    std::string getName() const override { return "EXECUTING"; }
};
}

#endif