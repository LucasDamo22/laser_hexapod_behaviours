#include <laser_hexapod_behaviors/constants.hpp>
#include <laser_hexapod_behaviors/robot_state.hpp>
#include <laser_hexapod_behaviors/cross_obstacle_new.hpp>

namespace laser_hexapod_behaviors
{
  std::unique_ptr<RobotState> SlipRecoveryState::update(CrossObstacle &ctx, const RobotInputs &inputs)
  {
    bool accident_uncoupled = false;

    // Loop through legs
    for (auto i = 0; i <= LL3; i++)
    {
      // Check for slippage conditions
      if (ctx.current_legs_reference_.foot_state[i].data == "stance" &&
          !inputs.contact_sensors.data[i] &&
          ctx.references_per_step_[ctx.current_step_].first != i &&
          inputs.foot_errors[i].data < 0.01)
      {
        accident_uncoupled = true;
        for (auto j = ctx.current_step_; j >= 0; j--)
        {

          if (ctx.references_per_step_[j].first == i && ctx.references_per_step_[j].second[4] == NEED_COUPLE)
          {

            if (ctx.references_per_step_[j].second[3] == REFERENCE_IN_WORLD)
            {
              if (ctx.references_per_step_[j].second[0] != NONE)
              {
                ctx.legs_world_reference_.points[i].x += 0.005 * ctx.references_per_step_[j].second[0];
              }

              if (ctx.references_per_step_[j].second[1] != NONE)
              {
                ctx.legs_world_reference_.points[i].y += 0.005 * ctx.references_per_step_[j].second[1];
              }

              if (ctx.references_per_step_[j].second[2] != NONE)
              {
                ctx.legs_world_reference_.points[i].z += 0.005 * ctx.references_per_step_[j].second[2];
              }
              ctx.transformReferenceWorldToCoxa(i);
            }
            else
            {
              ctx.current_legs_reference_.reference.points[i].z += -0.005;
            }

            ctx.current_legs_reference_.requested_leg_to_move[i].data = true;
            ctx.current_legs_reference_.foot_state[i].data = "stance";
          }
        }
      }
    }

    if (accident_uncoupled)
    {
      return nullptr; // abort execution because it slipped
    }

    // return next state
    return std::make_unique<ExecutingState>();
  }
}