#include <laser_hexapod_behaviors/constants.hpp>
#include <laser_hexapod_behaviors/robot_state.hpp>
#include <laser_hexapod_behaviors/cross_obstacle_new.hpp>
namespace laser_hexapod_behaviors
{

    std::unique_ptr<RobotState> AdaptativeErrorState::update(CrossObstacle &ctx, const RobotInputs &inputs)
    {

        // auto logger = rclcpp::get_logger("stabilizing_debug");
        // 1. Check if we are still unstable
        if (inputs.max_error > ctx.admitted_error_)
        {
            // THROTTLED: Print this only once every 500ms to stop spam
            // RCLCPP_WARN(logger,
            //             "Unstable! Current Error: %.4f > Admitted: %.4f",
            //             inputs.max_error, ctx.admitted_error_);

            // RCLCPP_WARN(logger,
            //             "Stabilization Counter: %d/5", ctx.adaptative_error_aux);

            ctx.adaptative_error_aux++;
            if (ctx.adaptative_error_aux == 5)
            {
                // RCLCPP_WARN(logger, "Unstable! Current Error: %.4f > Admitted: %.4f",
                //         inputs.max_error, ctx.admitted_error_ );

                // RCLCPP_WARN(logger, "Stabilization Counter: %d/5", ctx.adaptative_error_aux);

                float old_admitted = ctx.admitted_error_;
                ctx.admitted_error_ += 0.005;
                ctx.adaptative_error_aux = 0;

                // // IMMEDIATE: Keep this strictly immediate so you see exactly when the limit changes
                // RCLCPP_WARN(logger, ">>> LIMIT REACHED! Increasing Tolerance: %.4f -> %.4f",
                //             old_admitted, ctx.admitted_error_);
            }
            // error detected, returns null to abort execution
            return nullptr;
        }

        // IMMEDIATE: This only happens once when leaving the state
        // RCLCPP_INFO(logger, "Stable achieved (Error: %.4f). Resetting baseline and exiting.", inputs.max_error);

        // 2. If stable, reset counters and transition to slippage check state
        ctx.admitted_error_ = ctx.error_aux; // Reset baseline
        return std::make_unique<SlipRecoveryState>();
    }
}