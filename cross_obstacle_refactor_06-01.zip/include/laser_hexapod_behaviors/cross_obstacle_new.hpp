#ifndef LASER_HEXAPOD_BEHAVIORS__CROSS_OBSTACLE_NEW_HPP
#define LASER_HEXAPOD_BEHAVIORS__CROSS_OBSTACLE_NEW_HPP

#include <Eigen/Dense>
#include <iostream>

#include <geometry_msgs/msg/point.hpp>
#include <std_msgs/msg/float64.hpp>

#include <laser_msgs/msg/legs_reference_request.hpp>
#include <laser_msgs/msg/point_array.hpp>
#include <laser_msgs/msg/bool_array.hpp>
#include <laser_msgs/msg/rpy.hpp>
#include <sensor_msgs/msg/imu.hpp>

#include <tf2/LinearMath/Quaternion.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <rclcpp/rclcpp.hpp>

namespace laser_hexapod_behaviors
{

class RobotState;

using StepSequence = std::vector<std::pair<int, std::vector<double>>>;

class CrossObstacle {
public:
  CrossObstacle();
  CrossObstacle(std::vector<double> distance_body_to_coxa, float admitted_error);

  laser_msgs::msg::LegsReferenceRequest updateStep(laser_msgs::msg::BoolArray contact_sensor, std::vector<std_msgs::msg::Float64> foots_position_error,
                                                   float highest_foot_position_error);
  void                                  resetBehavior();
  int                                   getCurrentStep();
  int                                   getTotalSteps();
  void referencePerStep(sensor_msgs::msg::Imu imu_data);
  
  friend class AdaptativeErrorState;
  friend class SlipRecoveryState;
  friend class ExecutingState;

private:
  int cross_obstacle_update_counter;
  std::unique_ptr<RobotState> current_state_;
  void transformReferenceWorldToCoxa(int index_leg);

  int adaptative_error_aux;
  float error_aux;
 
  float                                  distance_coxa_to_wall_;
  float                                  admitted_error_;
  StepSequence                           references_per_step_;
  std::vector<geometry_msgs::msg::Point> distance_body_to_coxa_;
  geometry_msgs::msg::Point              body_position_;
  laser_msgs::msg::Rpy                   body_orientation_;
  int                                    current_step_;
  laser_msgs::msg::LegsReferenceRequest  current_legs_reference_;
  laser_msgs::msg::PointArray            legs_world_reference_;
};
}  // namespace laser_hexapod_behaviors

#endif

