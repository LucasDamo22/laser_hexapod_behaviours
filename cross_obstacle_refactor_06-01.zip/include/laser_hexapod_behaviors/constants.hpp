#ifndef LASER_HEXAPOD_BEHAVIORS__CONSTANTS_HPP
#define LASER_HEXAPOD_BEHAVIORS__CONSTANTS_HPP
#include <laser_hexapod_behaviors/angles.hpp>

#define LR1 0
#define LR2 1
#define LR3 2
#define LL1 3
#define LL2 4
#define LL3 5

#define BODY 6

#define NONE 12

#define REFERENCE_IN_COXA 13
#define REFERENCE_IN_WORLD 14

#define NEED_COUPLE 15

#endif