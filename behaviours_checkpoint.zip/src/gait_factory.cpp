#include <laser_hexapod_behaviors/gait_strategies.hpp>
#include <laser_hexapod_behaviors/constants.hpp>
#include <cmath> // for std::abs

namespace laser_hexapod_behaviors
{
    using namespace angles;

std::unique_ptr<GaitSequence> GaitFactory::createGait(double roll, double pitch) {
    
    double abs_roll = std::abs(roll);

    // Teto logic
    if (abs_roll <= DEG_180 && abs_roll >= DEG_90) { //180 90
        return std::make_unique<CeilingGait>();
    }
    
    // Parede logic
    else if (abs_roll <= DEG_90 && abs_roll >= DEG_15) { //90 10?
        if (pitch >= DEG_27 && pitch <= DEG_153) {          //27? 150?
            return std::make_unique<WallDownGait>();
        }
        else if (pitch >= -(DEG_153) && pitch <= -(DEG_27)) {
            return std::make_unique<WallUpGait>();
        }
        else {
            return std::make_unique<WallSideGait>();
        }
    }

    // Default
    return std::make_unique<GroundGait>();
}

} // namespace