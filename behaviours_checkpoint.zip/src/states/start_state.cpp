#include <laser_hexapod_behaviors/constants.hpp>
#include <laser_hexapod_behaviors/robot_state.hpp>
#include <laser_hexapod_behaviors/cross_obstacle_new.hpp>

namespace laser_hexapod_behaviors {
std::unique_ptr<RobotState> StartState::update(CrossObstacle& ctx, const RobotInputs& inputs) {
    return std::make_unique<AdaptativeErrorState>();
}
}