#include <laser_hexapod_behaviors/transition_plans.hpp>

namespace laser_hexapod_behaviors
{
/* TransitionPlans() {default} //{ */
TransitionPlans::TransitionPlans() {
}
//}

/* TransitionPlans() //{ */
TransitionPlans::TransitionPlans(std::vector<double> distance_body_to_coxa) {
  distance_body_to_coxa_                        = std::vector<geometry_msgs::msg::Point>(6, geometry_msgs::msg::Point());
  legs_world_reference_.points                  = std::vector<geometry_msgs::msg::Point>(6, geometry_msgs::msg::Point());
  current_legs_reference_.reference.points      = std::vector<geometry_msgs::msg::Point>(6, geometry_msgs::msg::Point());
  current_legs_reference_.requested_leg_to_move = std::vector<std_msgs::msg::Bool>(6, std_msgs::msg::Bool());
  current_legs_reference_.foot_state            = std::vector<std_msgs::msg::String>(6, std_msgs::msg::String());

  adaptative_error_aux = 0;

  for (auto i = 0; i < 6; i++) {
    distance_body_to_coxa_[i].x = distance_body_to_coxa[0 + (i * 3)];
    distance_body_to_coxa_[i].y = distance_body_to_coxa[1 + (i * 3)];
    distance_body_to_coxa_[i].z = distance_body_to_coxa[2 + (i * 3)];
  }

  resetBehavior();
}  //}

/* referencePerStep() //{ */
void TransitionPlans::referencePerStep(sensor_msgs::msg::Imu &msg, float admitted_error_floor, float admitted_error_wall, float admitted_error_ceiling) {

  tf2::Quaternion q(msg.orientation.x, msg.orientation.y, msg.orientation.z, msg.orientation.w);
  tf2::Matrix3x3(q).getRPY(roll_, pitch_, yaw_);

  /*     /1* externo //{ *1/ */
  /*     admitted_error_      = admitted_error_ceiling; */
  /*     error_aux      = admitted_error_; */
  /*     references_per_step_ = { */
  /*         {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 1 */
  /*         {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}, */
  /*         {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}, */
  /*         {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}, */
  /*         {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 5 */
  /*         {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}, */

  /*         {LR1, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}}, */
  /*         {LR1, {-0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}}, */
  /*         {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}, */

  /*         {LL3, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}},  // 10 */
  /*         {LL3, {-0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}}, */
  /*         {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}, */

  /*         {LL1, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}}, */
  /*         {LL1, {0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}}, */
  /*         {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 15 */

  /*         {LR3, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}}, */
  /*         {LR3, {0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}}, */
  /*         {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}, */

  /*         {LR2, {NONE, NONE, -0.20, REFERENCE_IN_COXA, NONE}}, */
  /*         {LR2, {NONE, 0.30, NONE, REFERENCE_IN_COXA, NONE}},  // 20 */
  /*         {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}, */

  /*         {LL2, {NONE, NONE, -0.20, REFERENCE_IN_COXA, NONE}}, */
  /*         {LL2, {NONE, 0.30, NONE, REFERENCE_IN_COXA, NONE}}, */
  /*         {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}, */

  /*         {BODY, {NONE, 0.05, -0.25, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 25 */

  /*         {LR2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR2, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LR1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR1, {NONE, -0.42, NONE, REFERENCE_IN_WORLD, NONE}},  // 30 */
  /*         {LR1, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LR3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR3, {NONE, -0.42, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR3, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {BODY, {NONE, 0.10, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 35 */

  /*         {LL2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL2, {NONE, 0.18, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL2, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LL3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL3, {NONE, 0.18, NONE, REFERENCE_IN_WORLD, NONE}},  // 40 */
  /*         {LL3, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LL1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL1, {NONE, 0.18, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL1, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {BODY, {NONE, 0.18, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 45 */

  /*         {LR2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR2, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR2, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LR3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR3, {NONE, -0.47, NONE, REFERENCE_IN_WORLD, NONE}},  // 50 */
  /*         {LR3, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LR1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR1, {NONE, -0.47, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR1, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {BODY, {NONE, 0.25, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 55 */

  /*         {LL2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL2, {NONE, 0.05, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL2, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LL1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL1, {NONE, 0.05, NONE, REFERENCE_IN_WORLD, NONE}},  // 60 */
  /*         {LL1, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LL3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL3, {NONE, 0.05, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL3, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {BODY, {NONE, 0.30, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 65 */

  /*         {LR2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR2, {NONE, -0.55, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR2, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LR1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR1, {NONE, -0.57, NONE, REFERENCE_IN_WORLD, NONE}},  // 70 */
  /*         {LR1, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LR3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR3, {NONE, -0.57, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR3, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {BODY, {NONE, 0.35, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 75 */

  /*         {LL2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL2, {NONE, -0.12, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL2, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LL3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL3, {NONE, -0.12, NONE, REFERENCE_IN_WORLD, NONE}},  // 80 */
  /*         {LL3, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LL1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL1, {NONE, -0.12, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL1, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {BODY, {NONE, 0.40, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 85 */

  /*         {LR2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR2, {NONE, -0.65, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR2, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LR3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR3, {NONE, -0.67, NONE, REFERENCE_IN_WORLD, NONE}},  // 90 */
  /*         {LR3, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LR1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR1, {NONE, -0.67, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR1, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {BODY, {NONE, 0.45, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 95 */

  /*         {LL2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL2, {NONE, -0.20, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL2, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LL1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL1, {NONE, -0.20, NONE, REFERENCE_IN_WORLD, NONE}},  // 100 */
  /*         {LL1, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {LL3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL3, {NONE, -0.20, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LL3, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

  /*         {BODY, {NONE, 0.50, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 105 */

  /*         {LR2, {NONE, NONE, 0.10, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR2, {NONE, -0.85, NONE, REFERENCE_IN_WORLD, NONE}}, */
  /*         {LR2, {NONE, NONE, -0.12, REFERENCE_IN_WORLD, NONE}}, */
  /*         /1* {LR2, {NONE, NONE, -1.0, REFERENCE_IN_WORLD, NEED_COUPLE}}, *1/ */


  /*         /1* {BODY, {NONE, NONE, NONE, 0.300, NONE, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */

  /*         /1* {BODY, {NONE, NONE, -0.32 * cos(body_orientation_.roll), NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */

  /*         /1* {BODY, {NONE, NONE, NONE, 0.26, NONE, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */

  /*         /1* {BODY, {NONE, 0.27, -0.43 * cos(1.0), NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */

  /*         /1* {BODY, {NONE, NONE, NONE, 0.65, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 60 *1/ */

  /*         /1* {LR1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LR1, {NONE, NONE, 0.61, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LR1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}}, *1/ */

  /*         /1* {LR3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LR3, {NONE, NONE, 0.61, REFERENCE_IN_WORLD, NONE}},  // 65 *1/ */
  /*         /1* {LR3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}}, *1/ */

  /*         /1* {LR2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LR2, {NONE, NONE, 0.64, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LR2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}}, *1/ */

  /*         /1* {BODY, {NONE, 0.30, -0.53 * cos(1.0), 0.70, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 70 *1/ */

  /*         /1* {BODY, {NONE, 0.37, -0.32, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */

  /*         /1* {BODY, {NONE, 0.40, -0.30, 0.80, NONE, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */

  /*         /1* {BODY, {NONE, 0.38, -0.22, 0.9, NONE, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */

  /*         /1* {BODY, {NONE, 0.35, -0.10, 1.05, NONE, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */

  /*         /1* {BODY, {NONE, 0.36, -0.08, 1.15, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 75 *1/ */

  /*         /1* {BODY, {NONE, 0.40, -0.01, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */

  /*         /1* {BODY, {NONE, 0.42, -0.00, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */

  /*         /1* {LL2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LL2, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LL2, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 80 *1/ */

  /*         /1* {LL1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LL1, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LL1, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}}, *1/ */

  /*         /1* {LL3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LL3, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NONE}},  // 85 *1/ */
  /*         /1* {LL3, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}}, *1/ */

  /*         /1* {BODY, {NONE, 0.40, 0.03, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */

  /*         /1* {LR1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LR1, {NONE, NONE, 0.75, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LR1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 90 *1/ */

  /*         /1* {LR3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LR3, {NONE, NONE, 0.75, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LR3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}}, *1/ */

  /*         /1* {LR2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LR2, {NONE, NONE, 0.75, REFERENCE_IN_WORLD, NONE}},  // 95 *1/ */
  /*         /1* {LR2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}}, *1/ */

  /*         /1* {LL1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LL1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LL1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}}, *1/ */

  /*         /1* {LL3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},  // 100 *1/ */
  /*         /1* {LL3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LL3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}}, *1/ */

  /*         /1* {LL2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LL2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}}, *1/ */
  /*         /1* {LL2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 105 *1/ */

  /*         /1* {BODY, {NONE, 0.45, 0.18, 1.30, NONE, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */

  /*         /1* {BODY, {NONE, NONE, NONE, 1.40, NONE, NONE, REFERENCE_IN_WORLD, NONE}}, *1/ */

  /*         /1* {LR1, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}}, *1/ */
  /*         /1* {LR1, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}}, *1/ */
  /*         /1* {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 110 *1/ */

  /*         /1* {LL3, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}}, *1/ */
  /*         /1* {LL3, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}}, *1/ */
  /*         /1* {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}, *1/ */

  /*         /1* {LL1, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}}, *1/ */
  /*         /1* {LL1, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},  // 115 *1/ */
  /*         /1* {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}, *1/ */

  /*         /1* {LR3, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}}, *1/ */
  /*         /1* {LR3, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}}, *1/ */
  /*         /1* {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}, *1/ */

  /*         /1* {LR2, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},  // 120 *1/ */
  /*         /1* {LR2, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}}, *1/ */
  /*         /1* {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}, *1/ */

  /*         /1* {LL2, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}}, *1/ */
  /*         /1* {LL2, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}}, *1/ */
  /*         /1* {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 125 *1/ */
  /*     }; */
  /*     //} */

  // {LEG, {X, Y, Z, REFERENCE_FRAME, NEED_COUPLE or NONE}}
  // {BODY, {X, Y, Z, ROLL, PITCH, YAW, REFERENCE_FRAME, NONE}}
  if (abs(roll_) <= 3.15 && abs(roll_) >= 1.58) {
    /* ceiling-wall //{ */
    admitted_error_      = admitted_error_ceiling;
    error_aux            = admitted_error_;
    references_per_step_ = {
        {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 1
        {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
        {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
        {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
        {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 5
        {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

        {LR1, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}},
        {LR1, {-0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
        {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

        {LL3, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}},  // 10
        {LL3, {-0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
        {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

        {LL1, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}},
        {LL1, {0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
        {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 15

        {LR3, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}},
        {LR3, {0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
        {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

        {LR2, {NONE, NONE, -0.20, REFERENCE_IN_COXA, NONE}},
        {LR2, {NONE, 0.30, NONE, REFERENCE_IN_COXA, NONE}},  // 20
        {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

        {LL2, {NONE, NONE, -0.20, REFERENCE_IN_COXA, NONE}},
        {LL2, {NONE, 0.30, NONE, REFERENCE_IN_COXA, NONE}},
        {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

        {BODY, {NONE, NONE, -0.25, 0.08, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 25

        {LR1, {NONE, NONE, 0.40, REFERENCE_IN_WORLD, NONE}},
        {LR1, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
        {LR1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {LR3, {NONE, NONE, 0.40, REFERENCE_IN_WORLD, NONE}},
        {LR3, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},  // 30
        {LR3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {LR2, {NONE, NONE, 0.43, REFERENCE_IN_WORLD, NONE}},
        {LR2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
        {LR2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {BODY, {NONE, 0.09, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 35

        {LL2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
        {LL2, {NONE, 0.18, NONE, REFERENCE_IN_WORLD, NONE}},
        {LL2, {NONE, NONE, -1.5, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {LL3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
        {LL3, {NONE, 0.18, NONE, REFERENCE_IN_WORLD, NONE}},  // 40
        {LL3, {NONE, NONE, -1.5, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {LL1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
        {LL1, {NONE, 0.18, NONE, REFERENCE_IN_WORLD, NONE}},
        {LL1, {NONE, NONE, -1.5, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {BODY, {NONE, NONE, NONE, 0.150, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 45

        {BODY, {NONE, 0.16, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {LR1, {NONE, -0.35, NONE, REFERENCE_IN_WORLD, NONE}},
        {LR1, {NONE, NONE, 0.52, REFERENCE_IN_WORLD, NONE}},
        {LR1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {LR3, {NONE, -0.35, NONE, REFERENCE_IN_WORLD, NONE}},  // 50
        {LR3, {NONE, NONE, 0.52, REFERENCE_IN_WORLD, NONE}},
        {LR3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {LR2, {NONE, -0.35, NONE, REFERENCE_IN_WORLD, NONE}},
        {LR2, {NONE, NONE, 0.54, REFERENCE_IN_WORLD, NONE}},
        {LR2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 55

        {BODY, {NONE, NONE, NONE, 0.300, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {BODY, {NONE, NONE, -0.32 * cos(body_orientation_.roll), NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {BODY, {NONE, NONE, NONE, 0.26, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {BODY, {NONE, 0.27, -0.43 * cos(1.0), NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {BODY, {NONE, NONE, NONE, 0.65, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 60

        {LR1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
        {LR1, {NONE, NONE, 0.61, REFERENCE_IN_WORLD, NONE}},
        {LR1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {LR3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
        {LR3, {NONE, NONE, 0.61, REFERENCE_IN_WORLD, NONE}},  // 65
        {LR3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {LR2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
        {LR2, {NONE, NONE, 0.64, REFERENCE_IN_WORLD, NONE}},
        {LR2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {BODY, {NONE, 0.30, -0.53 * cos(1.0), 0.70, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 70

        {BODY, {NONE, 0.37, -0.32, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {BODY, {NONE, 0.40, -0.30, 0.80, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {BODY, {NONE, 0.38, -0.22, 0.9, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {BODY, {NONE, 0.35, -0.10, 1.05, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {BODY, {NONE, 0.36, -0.08, 1.15, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 75

        {BODY, {NONE, 0.40, -0.01, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {BODY, {NONE, 0.42, -0.00, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {LL2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
        {LL2, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NONE}},
        {LL2, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 80

        {LL1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
        {LL1, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NONE}},
        {LL1, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {LL3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
        {LL3, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NONE}},  // 85
        {LL3, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {BODY, {NONE, 0.40, 0.03, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {LR1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
        {LR1, {NONE, NONE, 0.75, REFERENCE_IN_WORLD, NONE}},
        {LR1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 90

        {LR3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
        {LR3, {NONE, NONE, 0.75, REFERENCE_IN_WORLD, NONE}},
        {LR3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {LR2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
        {LR2, {NONE, NONE, 0.75, REFERENCE_IN_WORLD, NONE}},  // 95
        {LR2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {LL1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
        {LL1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
        {LL1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {LL3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},  // 100
        {LL3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
        {LL3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

        {LL2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
        {LL2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
        {LL2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 105

        {BODY, {NONE, 0.45, 0.18, 1.30, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {BODY, {NONE, NONE, NONE, 1.40, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

        {LR1, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
        {LR1, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
        {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 110

        {LL3, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
        {LL3, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
        {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

        {LL1, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
        {LL1, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},  // 115
        {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

        {LR3, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
        {LR3, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
        {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

        {LR2, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},  // 120
        {LR2, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
        {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

        {LL2, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
        {LL2, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
        {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 125
    };
    //} teto
  }

  else if (abs(roll_) <= 1.58 && abs(roll_) >= 0.2) {
    if (pitch_ >= 0.47 && pitch_ <= 2.67) {
      /* wall-floor //{ */
      admitted_error_      = admitted_error_wall;
      error_aux            = admitted_error_;
      references_per_step_ = {
          {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 1
          {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
          {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
          {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
          {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 5
          {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LR1, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}},
          {LR1, {-0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
          {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LL3, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}},  // 10
          {LL3, {-0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
          {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LL1, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}},
          {LL1, {0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
          {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 15

          {LR3, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}},
          {LR3, {0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
          {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LR2, {NONE, NONE, -0.20, REFERENCE_IN_COXA, NONE}},
          {LR2, {NONE, 0.30, NONE, REFERENCE_IN_COXA, NONE}},  // 20
          {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LL2, {NONE, NONE, -0.20, REFERENCE_IN_COXA, NONE}},
          {LL2, {NONE, 0.30, NONE, REFERENCE_IN_COXA, NONE}},
          {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {BODY, {NONE, NONE, -0.25, 0.08, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 25

          {LR1, {NONE, NONE, 0.40, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR3, {NONE, NONE, 0.40, REFERENCE_IN_WORLD, NONE}},
          {LR3, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},  // 30
          {LR3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR2, {NONE, NONE, 0.43, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {BODY, {NONE, 0.09, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 35

          {LL2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
          {LL2, {NONE, 0.18, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL2, {NONE, NONE, -1.5, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LL3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
          {LL3, {NONE, 0.18, NONE, REFERENCE_IN_WORLD, NONE}},  // 40
          {LL3, {NONE, NONE, -1.5, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LL1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, 0.18, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, NONE, -1.5, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {BODY, {NONE, NONE, NONE, 0.150, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 45

          {BODY, {NONE, 0.16, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {LR1, {NONE, -0.35, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, NONE, 0.52, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR3, {NONE, -0.35, NONE, REFERENCE_IN_WORLD, NONE}},  // 50
          {LR3, {NONE, NONE, 0.52, REFERENCE_IN_WORLD, NONE}},
          {LR3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR2, {NONE, -0.35, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, NONE, 0.54, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 55

          {BODY, {NONE, NONE, NONE, 0.300, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, NONE, -0.32 * cos(body_orientation_.roll), NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, NONE, NONE, 0.26, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, 0.27, -0.43 * cos(1.0), NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, NONE, NONE, 0.65, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 60

          {LR1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, NONE, 0.61, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR3, {NONE, NONE, 0.61, REFERENCE_IN_WORLD, NONE}},  // 65
          {LR3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, NONE, 0.64, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {BODY, {NONE, 0.30, -0.53 * cos(1.0), 0.70, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 70

          {BODY, {NONE, 0.37, -0.32, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, 0.40, -0.30, 0.80, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, 0.38, -0.22, 0.9, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, 0.35, -0.10, 1.05, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, 0.36, -0.08, 1.15, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 75

          {BODY, {NONE, 0.40, -0.01, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, 0.45, -0.00, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // alterado

          {LL2, {NONE, NONE, 0.10, REFERENCE_IN_WORLD, NONE}},
          {LL2, {NONE, -0.10, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL2, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 80

          {LL1, {NONE, NONE, 0.10, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, -0.10, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LL3, {NONE, NONE, 0.10, REFERENCE_IN_WORLD, NONE}},
          {LL3, {NONE, -0.10, NONE, REFERENCE_IN_WORLD, NONE}},  // 85
          {LL3, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {BODY, {NONE, 0.48, 0.03, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {LR1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, NONE, 0.75, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 90

          {LR3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR3, {NONE, NONE, 0.75, REFERENCE_IN_WORLD, NONE}},
          {LR3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, NONE, 0.75, REFERENCE_IN_WORLD, NONE}},  // 95
          {LR2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {BODY, {NONE, 0.55, 0.18, 1.25, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {LR1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, NONE, 0.80, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 100

          {LR3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR3, {NONE, NONE, 0.80, REFERENCE_IN_WORLD, NONE}},
          {LR3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, NONE, 0.80, REFERENCE_IN_WORLD, NONE}},  // 105
          {LR2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {BODY, {NONE, 0.60, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {LL1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, NONE, 0.13, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 110

          {LL3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL3, {NONE, NONE, 0.13, REFERENCE_IN_WORLD, NONE}},
          {LL3, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LL2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL2, {NONE, NONE, 0.13, REFERENCE_IN_WORLD, NONE}},  // 115
          {LL2, {NONE, -0.25, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {BODY, {NONE, 0.58, NONE, 1.40, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {LR1, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
          {LR1, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
          {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 120

          {LL3, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
          {LL3, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
          {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LL1, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
          {LL1, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},  // 125
          {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LR3, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
          {LR3, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
          {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LR2, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},  // 130
          {LR2, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
          {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LL2, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
          {LL2, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
          {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 135
      };

      //}
    } else if (pitch_ >= -2.67 && pitch_ <= -0.47) {
      /* wall-ceiling //{ */
      admitted_error_      = admitted_error_ceiling;
      error_aux            = admitted_error_;
      references_per_step_ = {
          {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 1
          {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
          {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
          {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
          {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 5
          {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LR1, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}},
          {LR1, {-0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
          {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LL3, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}},  // 10
          {LL3, {-0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
          {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LL1, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}},
          {LL1, {0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
          {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 15

          {LR3, {NONE, NONE, -0.18, REFERENCE_IN_COXA, NONE}},
          {LR3, {0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
          {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LR2, {NONE, NONE, -0.20, REFERENCE_IN_COXA, NONE}},
          {LR2, {NONE, 0.30, NONE, REFERENCE_IN_COXA, NONE}},  // 20
          {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LL2, {NONE, NONE, -0.20, REFERENCE_IN_COXA, NONE}},
          {LL2, {NONE, 0.30, NONE, REFERENCE_IN_COXA, NONE}},
          {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {BODY, {NONE, NONE, -0.25, 0.08, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 25

          {LR1, {NONE, NONE, 0.40, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, -0.75, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR3, {NONE, NONE, 0.40, REFERENCE_IN_WORLD, NONE}},
          {LR3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},  // 30
          {LR3, {NONE, -0.75, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR2, {NONE, NONE, 0.43, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, -0.35, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, -0.75, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {BODY, {NONE, 0.09, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 35

          {LL2, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
          {LL2, {NONE, 0.18, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL2, {NONE, NONE, -1.5, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LL3, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
          {LL3, {NONE, 0.18, NONE, REFERENCE_IN_WORLD, NONE}},  // 40
          {LL3, {NONE, NONE, -1.5, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LL1, {NONE, NONE, 0.05, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, 0.18, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, NONE, -1.5, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {BODY, {NONE, NONE, NONE, 0.150, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 45

          {BODY, {NONE, 0.16, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {LR1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, NONE, 0.52, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, -0.50, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},  // 50
          {LR3, {NONE, NONE, 0.52, REFERENCE_IN_WORLD, NONE}},
          {LR3, {NONE, -0.50, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR2, {NONE, -0.37, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, NONE, 0.55, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, -0.50, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 55

          {BODY, {NONE, NONE, NONE, 0.300, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, NONE, -0.32 * cos(body_orientation_.roll), NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, NONE, NONE, 0.26, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, 0.27, -0.43 * cos(1.0), NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, NONE, NONE, 0.60, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 60

          {LR1, {NONE, -0.37, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, NONE, 0.61, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, -1.5, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR3, {NONE, -0.37, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR3, {NONE, NONE, 0.61, REFERENCE_IN_WORLD, NONE}},  // 65
          {LR3, {NONE, -1.5, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR2, {NONE, -0.35, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, NONE, 0.64, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, -1.5, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {BODY, {NONE, 0.30, -0.45 * cos(1.0), 0.70, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 70

          {BODY, {NONE, 0.33, -0.23, 0.75, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, 0.36, -0.20, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},
          {BODY, {NONE, NONE, NONE, 0.80, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, 0.32, -0.24, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},
          {BODY, {NONE, NONE, NONE, 0.85, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  //  75

          {BODY, {NONE, 0.31, -0.21, 0.95, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {LR2, {NONE, -0.38, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, NONE, 0.62, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, -1.0, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR3, {NONE, -0.38, NONE, REFERENCE_IN_WORLD, NONE}},  // 80
          {LR3, {NONE, NONE, 0.61, REFERENCE_IN_WORLD, NONE}},
          {LR3, {NONE, -1.0, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR1, {NONE, -0.38, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, NONE, 0.61, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, -1.0, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 85

          {BODY, {NONE, 0.37, -0.19, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {LL2, {NONE, NONE, 0.01, REFERENCE_IN_WORLD, NONE}},
          {LL2, {NONE, 0.07, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL2, {NONE, NONE, -1.5, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LL3, {NONE, NONE, 0.01, REFERENCE_IN_WORLD, NONE}},  // 90
          {LL3, {NONE, 0.07, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL3, {NONE, NONE, -1.5, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LL1, {NONE, NONE, 0.01, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, 0.07, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, NONE, -1.5, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 95

          /* {LR1, {NONE, -0.38, NONE, REFERENCE_IN_WORLD, NONE}}, */
          /* {LR1, {NONE, -0.8, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}}, */
          /* {LR3, {NONE, -0.38, NONE, REFERENCE_IN_WORLD, NONE}}, */
          /* {LR3, {NONE, -0.8, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}}, */
          /* {LR2, {NONE, -0.38, NONE, REFERENCE_IN_WORLD, NONE}}, // 100 */
          /* {LR2, {NONE, -0.8, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}}, */

          {LR1, {NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 100
          {LR1, {NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          // talvez fazer o reacoplamento das LR em algum lugar aqui dentro
          {BODY, {NONE, NONE, NONE, 1.05, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, 0.50, -0.05, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, NONE, NONE, 1.15, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, NONE, -0.03, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 105

          {BODY, {NONE, NONE, NONE, 1.25, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, 0.49, 0.03, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},
          //

          {LL2, {NONE, NONE, 0.17, REFERENCE_IN_WORLD, NONE}},
          {LL2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL2, {NONE, NONE, 0.21, REFERENCE_IN_WORLD, NONE}},  // 110
          {LL2, {NONE, -0.50, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL2, {NONE, -1.0, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LL3, {NONE, NONE, 0.15, REFERENCE_IN_WORLD, NONE}},
          {LL3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL3, {NONE, NONE, 0.24, REFERENCE_IN_WORLD, NONE}},  // 115
          {LL3, {NONE, -0.55, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL3, {NONE, -1.0, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LL1, {NONE, NONE, 0.15, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, NONE, 0.24, REFERENCE_IN_WORLD, NONE}},  // 120
          {LL1, {NONE, -0.55, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, -1.0, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, NONE, 0.78, REFERENCE_IN_WORLD, NONE}},
          {LR2, {NONE, -1.0, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 125

          {LR3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR3, {NONE, NONE, 0.75, REFERENCE_IN_WORLD, NONE}},
          {LR3, {NONE, -1.0, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LR1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LR1, {NONE, NONE, 0.75, REFERENCE_IN_WORLD, NONE}},  // 130
          {LR1, {NONE, -1.0, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {BODY, {NONE, 0.55, NONE, 1.35, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {BODY, {NONE, NONE, 0.10, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {LL2, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL2, {NONE, NONE, 0.11, REFERENCE_IN_WORLD, NONE}},  // 135
          {LL2, {NONE, -1.0, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LL1, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, NONE, 0.13, REFERENCE_IN_WORLD, NONE}},
          {LL1, {NONE, -1.0, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {LL3, {NONE, -0.40, NONE, REFERENCE_IN_WORLD, NONE}},  // 140
          {LL3, {NONE, NONE, 0.13, REFERENCE_IN_WORLD, NONE}},
          {LL3, {NONE, -1.0, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

          {BODY, {NONE, NONE, 0.18, 1.40, NONE, NONE, REFERENCE_IN_WORLD, NONE}},
          {BODY, {NONE, NONE, 0.25, 1.57, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

          {LR1, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
          {LR1, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},  // 145
          {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LL3, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
          {LL3, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
          {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LL1, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},  // 150
          {LL1, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
          {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LR3, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
          {LR3, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
          {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},  // 155

          {LR2, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
          {LR2, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
          {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

          {LL2, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
          {LL2, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},  // 160
          {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
      };
      //}
    }
  }

  else {
    /* floor-wall //{ */
    admitted_error_      = admitted_error_floor;
    error_aux            = admitted_error_;
    references_per_step_ = {{LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
                            {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
                            {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
                            {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
                            {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},
                            {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

                            {LR1, {NONE, NONE, -0.08, REFERENCE_IN_COXA, NONE}},
                            {LR1, {-0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
                            {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

                            {LL3, {NONE, NONE, -0.08, REFERENCE_IN_COXA, NONE}},
                            {LL3, {-0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
                            {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

                            {LL1, {NONE, NONE, -0.08, REFERENCE_IN_COXA, NONE}},
                            {LL1, {0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
                            {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

                            {LR3, {NONE, NONE, -0.08, REFERENCE_IN_COXA, NONE}},
                            {LR3, {0.29 * cos(DEGREE_45), 0.29 * sin(DEGREE_45), NONE, REFERENCE_IN_COXA, NONE}},
                            {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

                            {LR2, {NONE, NONE, -0.08, REFERENCE_IN_COXA, NONE}},
                            {LR2, {NONE, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
                            {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

                            {LL2, {NONE, NONE, -0.08, REFERENCE_IN_COXA, NONE}},
                            {LL2, {NONE, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
                            {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

                            {BODY, {NONE, NONE, -0.45, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 25

                            {LR1, {NONE, NONE, 0.62, REFERENCE_IN_WORLD, NONE}},
                            {LR1, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR1, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LR3, {NONE, NONE, 0.62, REFERENCE_IN_WORLD, NONE}},
                            {LR3, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR3, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LR2, {NONE, NONE, 0.65, REFERENCE_IN_WORLD, NONE}},
                            {LR2, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR2, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL1, {NONE, NONE, 0.08, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, 0.14, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL3, {NONE, NONE, 0.08, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, 0.14, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL2, {NONE, NONE, 0.08, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, 0.14, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {BODY, {NONE, 0.05, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

                            {LL1, {NONE, NONE, 0.08, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, 0.08, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL3, {NONE, NONE, 0.08, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, 0.08, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 50

                            {LL2, {NONE, NONE, 0.08, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, 0.08, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {BODY, {NONE, 0.12, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

                            {LL1, {NONE, NONE, 0.10, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, 0.00, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL3, {NONE, NONE, 0.10, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, 0.00, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 60

                            {LL2, {NONE, NONE, 0.10, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, 0.00, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LR1, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR1, {NONE, NONE, 0.73, REFERENCE_IN_WORLD, NONE}},
                            {LR1, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LR3, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR3, {NONE, NONE, 0.73, REFERENCE_IN_WORLD, NONE}},
                            {LR3, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LR2, {NONE, -0.41, NONE, REFERENCE_IN_WORLD, NONE}},  // 70
                            {LR2, {NONE, NONE, 0.73, REFERENCE_IN_WORLD, NONE}},
                            {LR2, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {BODY, {NONE, NONE, NONE, 0.150, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

                            {BODY, {NONE, NONE, -0.48 * cos(0.150), NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

                            {BODY, {NONE, 0.5, -0.45 * cos(1.0), 1.0, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 75

                            {BODY, {NONE, 0.55, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

                            {LR2, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR2, {NONE, NONE, 0.85, REFERENCE_IN_WORLD, NONE}},
                            {LR2, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LR3, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},  // 80
                            {LR3, {NONE, NONE, 0.85, REFERENCE_IN_WORLD, NONE}},
                            {LR3, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LR1, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR1, {NONE, NONE, 0.85, REFERENCE_IN_WORLD, NONE}},
                            {LR1, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 85

                            {BODY, {NONE, 0.6, 0.05, 1.20173, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

                            {LL1, {NONE, NONE, 0.08, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, -0.12, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL3, {NONE, NONE, 0.08, REFERENCE_IN_WORLD, NONE}},  // 90
                            {LL3, {NONE, -0.12, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL2, {NONE, NONE, 0.08, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, -0.12, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 95

                            {LR1, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR1, {NONE, NONE, 0.87, REFERENCE_IN_WORLD, NONE}},
                            {LR1, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LR3, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR3, {NONE, NONE, 0.87, REFERENCE_IN_WORLD, NONE}},  // 100
                            {LR3, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LR2, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR2, {NONE, NONE, 0.87, REFERENCE_IN_WORLD, NONE}},
                            {LR2, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {BODY, {NONE, 0.62, 0.05, 1.39626, NONE, NONE, REFERENCE_IN_WORLD, NONE}},  // 105

                            {LL1, {NONE, NONE, 0.08, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, -0.10, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL3, {NONE, NONE, 0.08, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, -0.10, NONE, REFERENCE_IN_WORLD, NONE}},  // 110
                            {LL3, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL2, {NONE, NONE, 0.08, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, -0.10, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {BODY, {NONE, 0.60, 0.10, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

                            {LR1, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},  // 115
                            {LR1, {NONE, NONE, 0.90, REFERENCE_IN_WORLD, NONE}},
                            {LR1, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LR3, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR3, {NONE, NONE, 0.90, REFERENCE_IN_WORLD, NONE}},
                            {LR3, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 120

                            {LR2, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR2, {NONE, NONE, 0.90, REFERENCE_IN_WORLD, NONE}},
                            {LR2, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {BODY, {NONE, NONE, 0.13, 1.42, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

                            {LL1, {NONE, NONE, 0.10, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL3, {NONE, NONE, 0.10, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 130

                            {LL2, {NONE, NONE, 0.10, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, -0.15, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {BODY, {NONE, NONE, 0.18, 1.47, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

                            {LL1, {NONE, NONE, 0.10, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, -0.22, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL3, {NONE, NONE, 0.10, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, -0.22, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 140

                            {LL2, {NONE, NONE, 0.10, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, -0.22, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, NONE, -1, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {BODY, {NONE, NONE, 0.23, 1.57, NONE, NONE, REFERENCE_IN_WORLD, NONE}},
                            {BODY, {NONE, NONE, 0.28, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

                            {LL1, {NONE, NONE, 0.2, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, -0.16, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL3, {NONE, NONE, 0.2, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, -0.16, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 150

                            {LL2, {NONE, NONE, 0.2, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, -0.16, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {BODY, {NONE, 0.65, 0.29, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

                            {LR1, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR1, {NONE, NONE, 1.0, REFERENCE_IN_WORLD, NONE}},
                            {LR1, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LR3, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR3, {NONE, NONE, 1.0, REFERENCE_IN_WORLD, NONE}},
                            {LR3, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},  // 160

                            {LR2, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LR2, {NONE, NONE, 1.0, REFERENCE_IN_WORLD, NONE}},
                            {LR2, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL1, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, NONE, 0.30, REFERENCE_IN_WORLD, NONE}},
                            {LL1, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL3, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, NONE, 0.30, REFERENCE_IN_WORLD, NONE}},
                            {LL3, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {LL2, {NONE, -0.45, NONE, REFERENCE_IN_WORLD, NONE}},  // 170
                            {LL2, {NONE, NONE, 0.30, REFERENCE_IN_WORLD, NONE}},
                            {LL2, {NONE, -1, NONE, REFERENCE_IN_WORLD, NEED_COUPLE}},

                            {BODY, {NONE, 0.70, NONE, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},
                            {BODY, {NONE, NONE, 0.35, NONE, NONE, NONE, REFERENCE_IN_WORLD, NONE}},

                            {LR1, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
                            {LR1, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
                            {LR1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

                            {LL3, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
                            {LL3, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
                            {LL3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

                            {LL1, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
                            {LL1, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
                            {LL1, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

                            {LR3, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
                            {LR3, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
                            {LR3, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

                            {LR2, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},  // 180
                            {LR2, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},
                            {LR2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}},

                            {LL2, {NONE, NONE, -0.10, REFERENCE_IN_COXA, NONE}},
                            {LL2, {0.0, 0.29, NONE, REFERENCE_IN_COXA, NONE}},  // 190
                            {LL2, {NONE, NONE, NONE, REFERENCE_IN_COXA, NEED_COUPLE}}
                            };
    //}
  }
}
//}

/* updateStep() //{ */
laser_msgs::msg::LegsReferenceRequest TransitionPlans::updateStep(laser_msgs::msg::BoolArray          contact_sensor,
                                                                  std::vector<std_msgs::msg::Float64> foots_position_error, float highest_foot_position_error) {
  if (highest_foot_position_error > admitted_error_) {
    adaptative_error_aux++;
    if (adaptative_error_aux == 5) {
      admitted_error_ += 0.005;
      adaptative_error_aux = 0;
    }
    return current_legs_reference_;
  } else {
    admitted_error_ = error_aux;
  }

  bool accident_uncoupled = false;
  for (auto i = 0; i <= LL3; i++) {
    if (current_legs_reference_.foot_state[i].data == "stance" && !contact_sensor.data[i] && references_per_step_[current_step_].first != i &&
        foots_position_error[i].data < 0.01) {
      accident_uncoupled = true;

      for (auto j = current_step_; j >= 0; j--) {
        if (references_per_step_[j].first == i && references_per_step_[j].second[4] == NEED_COUPLE) {
          if (references_per_step_[j].second[3] == REFERENCE_IN_WORLD) {
            if (references_per_step_[j].second[0] != NONE) {
              legs_world_reference_.points[i].x += 0.005 * references_per_step_[j].second[0];
            }

            if (references_per_step_[j].second[1] != NONE) {
              legs_world_reference_.points[i].y += 0.005 * references_per_step_[j].second[1];
            }

            if (references_per_step_[j].second[2] != NONE) {
              legs_world_reference_.points[i].z += 0.005 * references_per_step_[j].second[2];
            }

            transformReferenceWorldToCoxa(i);
          } else {
            current_legs_reference_.reference.points[i].z += -0.005;
          }

          current_legs_reference_.requested_leg_to_move[i].data = true;
          current_legs_reference_.foot_state[i].data            = "stance";
        }
      }
    }
  }

  if (accident_uncoupled) {
    return current_legs_reference_;
  }

  for (auto i = 0; i <= LL3; i++) {
    current_legs_reference_.requested_leg_to_move[i].data = false;
    current_legs_reference_.foot_state[i].data            = "stance";
  }

  if (references_per_step_[current_step_].second[4] == NEED_COUPLE) {
    if (!contact_sensor.data[references_per_step_[current_step_].first] && foots_position_error[references_per_step_[current_step_].first].data < 0.01) {
      if (references_per_step_[current_step_].second[3] == REFERENCE_IN_WORLD) {
        if (references_per_step_[current_step_].second[0] != NONE) {
          legs_world_reference_.points[references_per_step_[current_step_].first].x += 0.005 * references_per_step_[current_step_].second[0];
        }

        if (references_per_step_[current_step_].second[1] != NONE) {
          legs_world_reference_.points[references_per_step_[current_step_].first].y += 0.005 * references_per_step_[current_step_].second[1];
        }

        if (references_per_step_[current_step_].second[2] != NONE) {
          legs_world_reference_.points[references_per_step_[current_step_].first].z += 0.005 * references_per_step_[current_step_].second[2];
        }

        transformReferenceWorldToCoxa(references_per_step_[current_step_].first);
      } else {
        current_legs_reference_.reference.points[references_per_step_[current_step_].first].z += -0.005;
      }

      current_legs_reference_.requested_leg_to_move[references_per_step_[current_step_].first].data = true;
      current_legs_reference_.foot_state[references_per_step_[current_step_].first].data            = "stance";
    } else if (contact_sensor.data[references_per_step_[current_step_].first]) {
      current_step_++;
    }
  } else if (references_per_step_[current_step_].first <= LL3) {
    if (references_per_step_[current_step_].second[0] != NONE) {
      if (references_per_step_[current_step_].second[3] == REFERENCE_IN_WORLD) {
        legs_world_reference_.points[references_per_step_[current_step_].first].x = references_per_step_[current_step_].second[0];
      } else {
        current_legs_reference_.reference.points[references_per_step_[current_step_].first].x = references_per_step_[current_step_].second[0];
      }
    }

    if (references_per_step_[current_step_].second[1] != NONE) {
      if (references_per_step_[current_step_].second[3] == REFERENCE_IN_WORLD) {
        legs_world_reference_.points[references_per_step_[current_step_].first].y = references_per_step_[current_step_].second[1];
      } else {
        current_legs_reference_.reference.points[references_per_step_[current_step_].first].y = references_per_step_[current_step_].second[1];
      }
    }

    if (references_per_step_[current_step_].second[2] != NONE) {
      if (references_per_step_[current_step_].second[3] == REFERENCE_IN_WORLD) {
        legs_world_reference_.points[references_per_step_[current_step_].first].z = references_per_step_[current_step_].second[2];
      } else {
        current_legs_reference_.reference.points[references_per_step_[current_step_].first].z = references_per_step_[current_step_].second[2];
      }
    }

    if (references_per_step_[current_step_].second[3] == REFERENCE_IN_WORLD) {
      transformReferenceWorldToCoxa(references_per_step_[current_step_].first);
    }

    current_legs_reference_.requested_leg_to_move[references_per_step_[current_step_].first].data = true;
    current_legs_reference_.foot_state[references_per_step_[current_step_].first].data            = "swing";

    current_step_++;
  } else if (references_per_step_[current_step_].first == BODY) {
    if (references_per_step_[current_step_].second[0] != NONE) {
      body_position_.x = references_per_step_[current_step_].second[0];
    }

    if (references_per_step_[current_step_].second[1] != NONE) {
      body_position_.y = references_per_step_[current_step_].second[1];
    }

    if (references_per_step_[current_step_].second[2] != NONE) {
      body_position_.z = references_per_step_[current_step_].second[2];
    }

    if (references_per_step_[current_step_].second[3] != NONE) {
      body_orientation_.roll = references_per_step_[current_step_].second[3];
    }

    if (references_per_step_[current_step_].second[4] != NONE) {
      body_orientation_.pitch = references_per_step_[current_step_].second[4];
    }

    if (references_per_step_[current_step_].second[5] != NONE) {
      body_orientation_.yaw = references_per_step_[current_step_].second[5];
    }

    for (auto i = 0; i <= LL3; i++) {
      transformReferenceWorldToCoxa(i);
      current_legs_reference_.requested_leg_to_move[i].data = true;
      current_legs_reference_.foot_state[i].data            = "stance";
    }

    current_step_++;
  }

  return current_legs_reference_;
}
//}

/* resetBehavior() //{ */
void TransitionPlans::resetBehavior() {
  current_step_ = 0;

  for (auto i = 0; i < 6; i++) {
    legs_world_reference_.points[i].x = 0;
    if (i <= LR3) {
      legs_world_reference_.points[i].y = -0.29;
    } else {
      legs_world_reference_.points[i].y = 0.29;
    }
    legs_world_reference_.points[i].z = 0.0;

    current_legs_reference_.reference.points[i].x = 0;
    current_legs_reference_.reference.points[i].y = 0.29;
    current_legs_reference_.reference.points[i].z = -0.21;

    current_legs_reference_.foot_state[i].data = "stance";
  }

  body_position_.x = 0;
  body_position_.y = 0;
  body_position_.z = 0;

  body_orientation_.roll  = 0;
  body_orientation_.pitch = 0;
  body_orientation_.yaw   = 0;
}
//}

/* getCurrentStep() //{ */
int TransitionPlans::getCurrentStep() {
  return current_step_;
}
//}

/* getTotalSteps() //{ */
int TransitionPlans::getTotalSteps() {
  return references_per_step_.size();
}
//}

/* transformReferenceWorldToCoxa() //{ */
void TransitionPlans::transformReferenceWorldToCoxa(int index_leg) {
  Eigen::Matrix4d translation_wb = Eigen::Matrix4d::Identity();
  translation_wb(0, 3)           = body_position_.x;
  translation_wb(1, 3)           = body_position_.y;
  translation_wb(2, 3)           = body_position_.z;

  Eigen::Matrix4d transform_wb = Eigen::Matrix4d::Identity();
  transform_wb(0, 3)           = legs_world_reference_.points[index_leg].x + distance_body_to_coxa_[index_leg].x;
  transform_wb(1, 3)           = legs_world_reference_.points[index_leg].y + distance_body_to_coxa_[index_leg].y;
  transform_wb(2, 3)           = legs_world_reference_.points[index_leg].z + distance_body_to_coxa_[index_leg].z;

  Eigen::Matrix4d rot_x_wb = Eigen::Matrix4d::Identity();
  rot_x_wb(1, 1)           = cos(body_orientation_.roll);
  rot_x_wb(1, 2)           = -sin(body_orientation_.roll);
  rot_x_wb(2, 1)           = sin(body_orientation_.roll);
  rot_x_wb(2, 2)           = cos(body_orientation_.roll);

  Eigen::Matrix4d rot_y_wb = Eigen::Matrix4d::Identity();
  rot_y_wb(0, 0)           = cos(body_orientation_.pitch);
  rot_y_wb(0, 2)           = sin(body_orientation_.pitch);
  rot_y_wb(2, 0)           = -sin(body_orientation_.pitch);
  rot_y_wb(2, 2)           = cos(body_orientation_.pitch);

  Eigen::Matrix4d rot_z_wb = Eigen::Matrix4d::Identity();
  rot_z_wb(0, 0)           = cos(body_orientation_.yaw);
  rot_z_wb(0, 1)           = -sin(body_orientation_.yaw);
  rot_z_wb(1, 0)           = sin(body_orientation_.yaw);
  rot_z_wb(1, 1)           = cos(body_orientation_.yaw);

  Eigen::Matrix4d result = translation_wb * rot_x_wb * rot_y_wb * rot_z_wb * transform_wb;

  Eigen::Matrix4d translation_bc = Eigen::Matrix4d::Identity();
  translation_bc(0, 3)           = -distance_body_to_coxa_[index_leg].x;
  translation_bc(1, 3)           = -distance_body_to_coxa_[index_leg].y;
  translation_bc(2, 3)           = -distance_body_to_coxa_[index_leg].z;

  Eigen::Matrix4d rot_z_bc = Eigen::Matrix4d::Identity();

  float leg_rotation = 0.0;
  switch (index_leg) {
    case LR1:
      leg_rotation = DEGREE_225;
      break;
    case LR2:
      leg_rotation = DEGREE_180;
      break;
    case LR3:
      leg_rotation = DEGREE_135;
      break;
    case LL1:
      leg_rotation = DEGREE_315;
      break;
    case LL2:
      leg_rotation = DEGREE_0;
      break;
    case LL3:
      leg_rotation = DEGREE_45;
      break;
  }

  rot_z_bc(0, 0) = cos(leg_rotation);
  rot_z_bc(0, 1) = -sin(leg_rotation);
  rot_z_bc(1, 0) = sin(leg_rotation);
  rot_z_bc(1, 1) = cos(leg_rotation);

  result = rot_z_bc * translation_bc * result;

  current_legs_reference_.reference.points[index_leg].x = result(0, 3);
  current_legs_reference_.reference.points[index_leg].y = result(1, 3);
  current_legs_reference_.reference.points[index_leg].z = result(2, 3);
}
//}
}  // namespace laser_hexapod_behaviors
